<?php get_header(); ?>
	<div class="wltstthm-content">
		<div class="container">
			<div class="row">
				<div class="col-12 col-md-9 left-column">
					
					<p><?php esc_html_e( 'Sorry, no posts matched your criteria.', 'wltstthm' ); ?></p>

				</div><!-- .left-column -->

				
					<?php get_sidebar() ?>
				</div><!-- .right-column -->
			</div><!-- .row -->
		</div><!-- .container -->
	
<?php get_footer(); ?>
