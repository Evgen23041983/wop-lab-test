(function($){
    $( document ).ready(function(){

        $('input[name="color_car"]').wpColorPicker();



    });
})(jQuery);